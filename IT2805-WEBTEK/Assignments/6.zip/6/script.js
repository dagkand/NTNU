function calcTax() {
    var income = document.getElementById("income").value;
    var wealth = document.getElementById("wealth").value;
    var tax =  parseInt(0.35 * income) + parseInt(0.25 * wealth);
    //console.log(tax)
    document.getElementById("tax").value = (tax);
}

